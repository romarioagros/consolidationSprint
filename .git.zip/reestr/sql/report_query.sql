 with start_report as (
                 SELECT 
                    period_name,
                    B.name, B.amount, B.num_cg_direction, cost_with_vat,
                    I.id_agr
                FROM sms.blinov_a2p B
	 			left join description.companies C on 
                    b.num_cg_direction = C.id	
                left join agrements.ids I on 
                    C.mother_id = I.mother_id
                left join agrements.periods P
                    on B.start_date = P.period_start and B.end_date = P.period_end
               
	 			WHERE period_name = %(period_name)s
            ),
			infobip as (
			
				SELECT 
                    period_name,
                    'infobip' name, ammount_sms, 14 num_cg_direction , cost_with_vat,
                    I.id_agr
                FROM sms.infobip B
                left join agrements.ids I on 
                    21 = I.mother_id
                left join agrements.periods P
                    on B.period_start = P.period_start and B.period_end = P.period_end
               WHERE period_name = %(period_name)s
			
			),

			union_table as (
			select * from 	 start_report
				union all 
			select * from 	infobip
			),

			
            ids_tab as (
                select id_agr , sum(cost_with_vat) cost_vat, sum(amount) ammount
                from union_table
                group by id_agr
            )

          select 
          A.id,
		  A.service_id,
		  revenue_type,
		  contractor,
		  contract_number,
		  sign_date,
		  subject,
		  code,
		  "type",
		  status,

		   ammount,
		  CAST(ROUND(cost_vat::numeric, 2) AS numeric(10,2)) as cost_vat
           from agrements.reestr A
           left join ids_tab I on A.id = I.id_agr
			
			
			
			
--select * from union_table			