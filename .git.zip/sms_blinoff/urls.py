from django.urls import path
from . import views

app_name = 'sms_blinoff'   # пространство имён для именованных URL этой аппки

urlpatterns = [
    path('tranks/', views.company_list, name='company_list'),
    path("companies/add/", views.add_company, name="add_account"),
    path("mother/add/", views.add_mother, name="add_mother"),
    path("mother/", views.mother_list, name="mother_list"),
    path("alfa/",       views.alfa_list,    name="alfa_list"),
    path("alfa/add/",   views.add_alfa,     name="add_alfa"),
    path("services/",      views.sms_services,  name="sms_services"),
    path("category3/", views.category3_list, name="category3_list"),
    path('paymed_sms/', views.paymed_sms_list, name='paymed_sms_list'),
    path("sms_periode/", views.sms_periode,        name="sms_periode"),
    path("sms_periode/<str:period>/", views.sms_periode, name="sms_periode"),
]